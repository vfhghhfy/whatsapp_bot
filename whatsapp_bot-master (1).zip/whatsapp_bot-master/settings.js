const settings = {
  packname: 'Kenny Bot',
  author: 'Wambugu Kinyua',
  botName: "Kinyua Bot",
  botOwner: 'Wambugu Kinyua', // Your name
  ownerNumber: '2547xxxxxx', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "3.0.0",
};

module.exports = settings;
